import './App.css';
import React from 'react';
import Navbar from './Navbar';
import Cards_Component from './Cards/Cards_Component.js';
import { Route, Link } from 'react-router-dom';


function App() {
  return (
    <>
    
      <Navbar></Navbar>
      <Cards_Component></Cards_Component>
    
      
    </>
  );
}

export default App;