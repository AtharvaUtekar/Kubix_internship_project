import React from 'react';
import Card from 'react-bootstrap/Card';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import Container from 'react-bootstrap/Container';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import '../index.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Cards_Component.css'
import comp_logo from './company_logo.png'
import { BiSearchAlt } from "react-icons/bi";

const CardComponent = () => {
    return (

        <div className="cards">
           
            <Container fluid>
            <Row>
            <Card border="info" xs={1} md={2} className="filtercard">
                  <Card.Body>
                    <Card.Title>Info Card Title</Card.Title>
                    <Row>
                    
                    <Col md="auto" className="searchfield">
                          <h6>Category</h6>
                          <Form.Control placeholder="eg. Web development" />
                    </Col>
                    <Col md="auto" className="searchfield">
                          <h6>Location</h6>
                          <Form.Control placeholder="eg. Mumbai" />
                    </Col>
                    <Col md="auto" className="searchfield">
                          <h6>Choose start date</h6>
                          <Form.Control type="date" name='date_of_birth' />
                    </Col>
                    <Col md="auto" className="searchfield">
                        <Form.Group as={Col} controlId="formGridState">
                          <h6>Choose duration</h6>
                              <Form.Select>
                                <option>1 month</option>
                                <option>2 months</option>
                                <option>3 months</option>
                                <option>4 months</option>
                                <option>6 months</option>
                                <option>12 months or higher</option>
                              </Form.Select>
                        </Form.Group>


                    </Col>
                    <Col md="auto" className="searchfield">
                    <Form.Check 
                          type="switch"
                          id="custom-switch"
                          label="Work from home"
                    />
                    <Form.Check 
                          type="switch"
                          id="custom-switch"
                          label="Part-time"
                    />
                    </Col>
                    <Col md="auto" className="searchfield">
                    <Form.Group className="mb-3 searchbar" controlId="formBasicCheckbox">
                      <Form.Check type="checkbox" label="Show internship" /> <em>as per my preferences</em>
                    </Form.Group>
                    </Col>
                    {/*
                    <Col md="auto" className="searchfield">
                      <Button variant="outline-primary" className="searchbar">
                      <BiSearchAlt size="1x" className="searchicon"></BiSearchAlt>
                      </Button>
                    </Col>
                    */}  
                    <Col md="auto" className="searchfield">
                    <h6> OR </h6>
                    </Col>
                    <Col md="auto" className="searchfield">
                    <h6>Search by keyword</h6>
                    <Form.Control placeholder="eg. Web development" /> 
                    </Col>
                    <Col md="auto" className="searchfield">
                      <Button variant="outline-primary" className="searchiconbar">
                      Search
                      <BiSearchAlt className="searchicon"></BiSearchAlt>
                      </Button>
                    </Col>
                  </Row>                   
                  </Card.Body>
                                
                </Card> 
            </Row>
            <Row>
              {Array.from({ length: 6 }).map((_, idx) => (
                <Col md="auto" >
                    <Card className="cards">
                        <Card.Body>
                          <Card.Title>Internship Title  
                          <img className="company_logos" src={comp_logo}></img>                                                    
                          <h5 classname="Company_name">
                            Internship company name
                          </h5>     
                          </Card.Title>                                                            
                          <Card.Text>
                          Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                          Donec vel mi ac velit consequat lacinia nec et tellus. Aliquam suscipit sem ut eros pulvinar auctor. 
                          </Card.Text>

                          <button class="apply_button"><span>Apply Now </span></button>
                          
                        </Card.Body>
                      </Card>
                  </Col>
                  ))}
            </Row>        
          </Container>
            
        </div>
    );
};

export default CardComponent;

